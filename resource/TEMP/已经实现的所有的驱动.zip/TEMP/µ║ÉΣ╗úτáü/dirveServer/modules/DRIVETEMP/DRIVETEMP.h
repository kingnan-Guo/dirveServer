#pragma once
#include <iostream>
#include <stdio.h>
#include <stdlib.h>


// #include <linux/module.h>
// #include <linux/fs.h>
// #include <linux/init.h>
// #include <linux/kernel.h>
// #include <linux/slab.h>




int DRIVETEMP_MAIN(int arch, char* argv[]);
