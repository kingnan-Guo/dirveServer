#include "DRIVETEMP.h"














int DRIVETEMP_MAIN(int arch, char* argv[]){
    std::cout << "DRIVETEMP_MAIN" << std::endl;
    return 0;
};