#include "dirveServerLog.h"


dirveServerLog::dirveServerLog(/* args */)
{
}

dirveServerLog::~dirveServerLog()
{
}


void dirveServerLog::initLog(){
    printf("dirveServerLog initLog\n");
}