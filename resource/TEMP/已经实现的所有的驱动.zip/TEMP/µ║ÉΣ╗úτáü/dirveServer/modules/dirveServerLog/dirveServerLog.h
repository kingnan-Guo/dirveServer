#pragma once
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

class dirveServerLog
{
    private:
    public:
        dirveServerLog();
        ~dirveServerLog();
        void initLog();
};

