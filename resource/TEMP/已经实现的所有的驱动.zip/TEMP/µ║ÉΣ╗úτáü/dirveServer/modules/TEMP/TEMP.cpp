#include "TEMP.h"















int TEMP_MAIN(int arch, char* argv[]){
    std::cout << "TEMP" << std::endl;
    return 0;
};