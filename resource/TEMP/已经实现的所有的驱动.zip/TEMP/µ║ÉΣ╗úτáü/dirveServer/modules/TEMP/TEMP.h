#pragma once
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

int TEMP_MAIN(int arch, char* argv[]);
